import React, { useState } from 'react'




function Home() {
 // const [{ contract, accounts }, dispatch] = useStore();
  // const [isTransactionInProcess, setTransactionInProcess] = useState(false)
  // const [isTransactionSuccessful, setTransactionSuccessful] = useState(true)
  // const [transactionError, setTransactionError] = useState("")




  return (
    <div >
      <h1>Welcome to Home page</h1>
    

    </div>
  );
}

export default Home;