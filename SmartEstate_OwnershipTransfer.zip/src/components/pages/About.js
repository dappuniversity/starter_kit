import React from 'react';
import { PropertyList } from '../PropertyList'

function About() {
    return (
      <div >
        <h1>Welcome to About page</h1>
        <PropertyList />
      </div>
    );
  }
  
  export default About;