import React from 'react';
import OfferStatus from '../OfferStatus';

function About() {
    return (
      <div >
        <h1>Welcome to About page</h1> 
         
       
      </div>
    );
  }
  
  export default About;