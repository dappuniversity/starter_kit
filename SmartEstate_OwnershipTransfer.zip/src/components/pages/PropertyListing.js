import React from 'react';
import { PropertyList } from '../PropertyList'

export default function propertyList() {
    return (
      <div >
        <PropertyList />
      </div>
    );
  }
